// background.js

let profiles = [];
let selectedProfileIndex = -1;

chrome.runtime.onInstalled.addListener(() => {
    // Initialize with a default profile if none exist
    if (profiles.length === 0) {
        profiles.push({ name: 'Default Profile', email: '', phone: '' });
        selectedProfileIndex = 0;
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getProfiles') {
        sendResponse({ profiles });
    } else if (request.action === 'addProfile') {
        const newProfile = { name: request.name, email: '', phone: '' };
        profiles.push(newProfile);
        selectedProfileIndex = profiles.length - 1;
        sendResponse({ success: true });
    } else if (request.action === 'selectProfile') {
        selectedProfileIndex = request.index;
        sendResponse({ success: true });
    } else if (request.action === 'getSelectedProfile') {
        if (selectedProfileIndex !== -1) {
            sendResponse({ profile: profiles[selectedProfileIndex] });
        } else {
            sendResponse({ profile: null });
        }
    }
});