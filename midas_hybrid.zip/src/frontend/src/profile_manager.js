// profile_manager.js

document.getElementById('add-profile-btn').addEventListener('click', () => {
    const newProfileName = prompt('Enter the name for the new profile:');
    if (newProfileName) {
        chrome.runtime.sendMessage({ action: 'addProfile', name: newProfileName }, (response) => {
            if (response.success) {
                updateProfileList();
            } else {
                alert('Failed to add new profile.');
            }
        });
    }
});

document.getElementById('profile-select').addEventListener('change', (event) => {
    const selectedIndex = event.target.selectedIndex;
    chrome.runtime.sendMessage({ action: 'selectProfile', index: selectedIndex }, () => {
        // Profile selection updated
    });
});

function updateProfileList() {
    chrome.runtime.sendMessage({ action: 'getProfiles' }, (response) => {
        const profileSelect = document.getElementById('profile-select');
        profileSelect.innerHTML = ''; // Clear existing options

        response.profiles.forEach((profile, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.textContent = profile.name;
            if (index === response.selectedProfileIndex) {
                option.selected = true;
            }
            profileSelect.appendChild(option);
        });
    });
}

// Initialize the profile list on popup load
updateProfileList();