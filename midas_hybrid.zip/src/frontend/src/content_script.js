// content_script.js

(function() {
    // Function to detect form fields and inject an "Auto-Fill" button
    function injectAutoFillButton() {
        const formFields = document.querySelectorAll('input, textarea, select');
        if (formFields.length > 0) {
            const autoFillButton = document.createElement('button');
            autoFillButton.textContent = 'Auto-Fill';
            autoFillButton.style.position = 'fixed';
            autoFillButton.style.top = '10px';
            autoFillButton.style.right = '10px';
            autoFillButton.style.zIndex = '9999';
            autoFillButton.style.padding = '10px 20px';
            autoFillButton.style.backgroundColor = '#007bff';
            autoFillButton.style.color = 'white';
            autoFillButton.style.border = 'none';
            autoFillButton.style.borderRadius = '4px';
            autoFillButton.style.cursor = 'pointer';

            autoFillButton.addEventListener('click', () => {
                // Fetch selected profile data from background script
                chrome.runtime.sendMessage({ action: 'getSelectedProfile' }, (response) => {
                    if (response.profile) {
                        const { name, email, phone } = response.profile;
                        formFields.forEach(field => {
                            switch (field.name.toLowerCase()) {
                                case 'name':
                                    field.value = name;
                                    break;
                                case 'email':
                                    field.value = email;
                                    break;
                                case 'phone':
                                    field.value = phone;
                                    break;
                            }
                        });
                    }
                });
            });

            document.body.appendChild(autoFillButton);
        }
    }

    // Run the function when the DOM is fully loaded
    if (document.readyState === 'complete') {
        injectAutoFillButton();
    } else {
        window.addEventListener('load', injectAutoFillButton);
    }
})();