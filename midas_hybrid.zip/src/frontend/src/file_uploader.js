// file_uploader.js

document.getElementById('upload-btn').addEventListener('click', () => {
    const fileInput = document.getElementById('resume-upload');
    const file = fileInput.files[0];

    if (file) {
        if (!file.type.match(/application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document/)) {
            alert('Please upload a PDF or DOCX file.');
            return;
        }

        const formData = new FormData();
        formData.append('resume', file);

        fetch('http://localhost:8080/api/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Resume uploaded successfully!');
            } else {
                alert('Failed to upload resume.');
            }
        })
        .catch(error => {
            console.error('Error uploading file:', error);
            alert('Network error. Please try again later.');
        });
    } else {
        alert('No file selected. Please choose a file to upload.');
    }
});