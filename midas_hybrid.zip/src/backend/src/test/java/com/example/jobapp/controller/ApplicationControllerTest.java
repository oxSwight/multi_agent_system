package com.example.jobapp.controller;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.*;
import static org.hamcrest.Matchers.*;

import com.example.jobapp.model.Profile;
import com.example.jobapp.service.ProfileService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

@WebMvcTest(ApplicationController.class)
public class ApplicationControllerTest {

    @Autowired
    private ProfileService profileService;

    @MockBean
    private ProfileRepository profileRepository;

    @BeforeEach
    public void setUp() {
        given()
            .standaloneSetup(new ApplicationController(profileService));
    }

    @Test
    public void testCreateProfile() {
        Profile profile = new Profile();
        profile.setName("John Doe");

        when()
            .post("/api/profiles")
            .contentType(MediaType.APPLICATION_JSON)
            .body("{\"name\":\"John Doe\"}")
        .then()
            .statusCode(200)
            .body(equalTo("1"));
    }

    @Test
    public void testGetProfileById() {
        Profile profile = new Profile();
        profile.setId(1);
        profile.setName("John Doe");

        when(profileRepository.findById(1)).thenReturn(java.util.Optional.of(profile));

        when()
            .get("/api/profiles/1")
        .then()
            .statusCode(200)
            .body("id", equalTo(1))
            .body("name", equalTo("John Doe"));
    }

    @Test
    public void testUploadFile() {
        given()
            .multiPart("file", "test.pdf", new byte[0])
        .when()
            .post("/api/files")
        .then()
            .statusCode(200)
            .body(equalTo("File uploaded successfully"));
    }

    @Test
    public void testUploadUnsupportedFileType() {
        given()
            .multiPart("file", "test.txt", new byte[0])
        .when()
            .post("/api/files")
        .then()
            .statusCode(400)
            .body(equalTo("Unsupported file type. Please upload a .pdf or .docx file."));
    }
}