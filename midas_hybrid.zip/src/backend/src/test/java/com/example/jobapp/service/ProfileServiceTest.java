package com.example.jobapp.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.jobapp.model.Profile;
import com.example.jobapp.repository.ProfileRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
public class ProfileServiceTest {

    @Autowired
    private ProfileService profileService;

    @MockBean
    private ProfileRepository profileRepository;

    private Profile testProfile;

    @BeforeEach
    public void setUp() {
        testProfile = new Profile();
        testProfile.setName("John Doe");
    }

    @Test
    public void testCreateProfile() {
        when(profileRepository.save(testProfile)).thenReturn(testProfile);

        int id = profileService.createProfile(testProfile);
        assertEquals(testProfile.getId(), id);
        verify(profileRepository, times(1)).save(testProfile);
    }

    @Test
    public void testGetProfileById() {
        when(profileRepository.findById(testProfile.getId())).thenReturn(java.util.Optional.of(testProfile));

        Profile retrievedProfile = profileService.getProfileById(testProfile.getId());
        assertNotNull(retrievedProfile);
        assertEquals(testProfile.getName(), retrievedProfile.getName());
        verify(profileRepository, times(1)).findById(testProfile.getId());
    }

    @Test
    public void testGetProfileByIdNotFound() {
        when(profileRepository.findById(testProfile.getId())).thenReturn(java.util.Optional.empty());

        Profile retrievedProfile = profileService.getProfileById(testProfile.getId());
        assertNull(retrievedProfile);
        verify(profileRepository, times(1)).findById(testProfile.getId());
    }
}