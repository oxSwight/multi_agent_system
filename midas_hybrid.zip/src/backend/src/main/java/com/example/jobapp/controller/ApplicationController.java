package com.example.jobapp.controller;

import com.example.jobapp.model.Profile;
import com.example.jobapp.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class ApplicationController {

    @Autowired
    private ProfileService profileService;

    @PostMapping("/profiles")
    public ResponseEntity<Integer> createProfile(@RequestBody Profile profile) {
        int id = profileService.createProfile(profile);
        return ResponseEntity.ok(id);
    }

    @GetMapping("/profiles/{id}")
    public ResponseEntity<Profile> getProfileById(@PathVariable int id) {
        Profile profile = profileService.getProfileById(id);
        if (profile != null) {
            return ResponseEntity.ok(profile);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/files")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        // Implement file validation and storage logic here
        if (!file.isEmpty() && (file.getContentType().equals("application/pdf") || file.getContentType().equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document"))) {
            // Save the file to a directory or database
            return ResponseEntity.ok("File uploaded successfully");
        } else {
            return ResponseEntity.badRequest().body("Unsupported file type. Please upload a .pdf or .docx file.");
        }
    }
}