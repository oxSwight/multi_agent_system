package com.example.jobapp.service;

import com.example.jobapp.model.Profile;
import com.example.jobapp.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    public int createProfile(Profile profile) {
        Profile savedProfile = profileRepository.save(profile);
        return savedProfile.getId();
    }

    public Profile getProfileById(int id) {
        return profileRepository.findById(id).orElse(null);
    }
}