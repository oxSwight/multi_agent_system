// file_uploader.test.js

import { jest } from '@jest/globals';

describe('File Uploader', () => {
    let fetchMock;

    beforeEach(() => {
        fetchMock = jest.spyOn(global, 'fetch').mockResolvedValue({
            json: jest.fn().mockResolvedValue({ success: true })
        });
    });

    afterEach(() => {
        fetchMock.mockRestore();
    });

    it('should upload a file successfully', async () => {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.files = [new File(['content'], 'test.txt')];

        const event = new Event('change');
        fileInput.dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(fetchMock).toHaveBeenCalledWith('http://localhost:3000/upload', {
            method: 'POST',
            body: fileInput.files[0],
            headers: {
                'Content-Type': 'application/octet-stream'
            }
        });
    });

    it('should handle successful upload response', async () => {
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.files = [new File(['content'], 'test.txt')];

        const event = new Event('change');
        fileInput.dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(alertMock).toHaveBeenCalledWith('Resume uploaded successfully!');
    });

    it('should handle failed upload response', async () => {
        fetchMock.mockResolvedValue({
            json: jest.fn().mockResolvedValue({ success: false })
        });

        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.files = [new File(['content'], 'test.txt')];

        const event = new Event('change');
        fileInput.dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(alertMock).toHaveBeenCalledWith('Failed to upload resume.');
    });

    it('should handle network error during upload', async () => {
        fetchMock.mockRejectedValue(new Error('Network error'));

        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.files = [new File(['content'], 'test.txt')];

        const event = new Event('change');
        fileInput.dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(alertMock).toHaveBeenCalledWith('Network error. Please try again later.');
    });

    it('should alert if no file is selected', async () => {
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.files = [];

        const event = new Event('change');
        fileInput.dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(alertMock).toHaveBeenCalledWith('No file selected. Please choose a file to upload.');
    });
});