// background.test.js

import { jest } from '@jest/globals';

describe('Background Script', () => {
    let profiles;
    let selectedProfileIndex;

    beforeEach(() => {
        profiles = [];
        selectedProfileIndex = -1;
    });

    it('should initialize with a default profile when the extension is installed', () => {
        chrome.runtime.onInstalled.addListener(() => {
            if (profiles.length === 0) {
                profiles.push({ name: 'Default Profile', email: '', phone: '' });
                selectedProfileIndex = 0;
            }
        });

        expect(profiles).toEqual([{ name: 'Default Profile', email: '', phone: '' }]);
        expect(selectedProfileIndex).toBe(0);
    });

    it('should return all profiles when requested', () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        profiles.push({ name: 'Profile 2', email: '', phone: '' });

        let receivedProfiles = [];
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'getProfiles') {
                sendResponse({ profiles });
                receivedProfiles = profiles;
            }
        });

        expect(receivedProfiles).toEqual(profiles);
    });

    it('should add a new profile when requested', () => {
        const newProfileName = 'New Profile';
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'addProfile') {
                const newProfile = { name: request.name, email: '', phone: '' };
                profiles.push(newProfile);
                selectedProfileIndex = profiles.length - 1;
                sendResponse({ success: true });
            }
        });

        expect(profiles).toEqual([{ name: 'New Profile', email: '', phone: '' }]);
        expect(selectedProfileIndex).toBe(0);
    });

    it('should select a profile when requested', () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        profiles.push({ name: 'Profile 2', email: '', phone: '' });

        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'selectProfile') {
                selectedProfileIndex = request.index;
                sendResponse({ success: true });
            }
        });

        expect(selectedProfileIndex).toBe(1);
    });

    it('should return the selected profile when requested', () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        profiles.push({ name: 'Profile 2', email: '', phone: '' });
        selectedProfileIndex = 1;

        let receivedProfile = null;
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'getSelectedProfile') {
                if (selectedProfileIndex !== -1) {
                    sendResponse({ profile: profiles[selectedProfileIndex] });
                    receivedProfile = profiles[selectedProfileIndex];
                } else {
                    sendResponse({ profile: null });
                }
            }
        });

        expect(receivedProfile).toEqual({ name: 'Profile 2', email: '', phone: '' });
    });

    it('should return null if no profile is selected when requested', () => {
        let receivedProfile = null;
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'getSelectedProfile') {
                if (selectedProfileIndex !== -1) {
                    sendResponse({ profile: profiles[selectedProfileIndex] });
                    receivedProfile = profiles[selectedProfileIndex];
                } else {
                    sendResponse({ profile: null });
                }
            }
        });

        expect(receivedProfile).toBeNull();
    });
});