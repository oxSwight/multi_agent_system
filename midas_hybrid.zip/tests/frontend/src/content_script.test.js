// content_script.test.js

import { jest } from '@jest/globals';
import { JSDOM } from 'jsdom';

describe('Content Script', () => {
    let dom;
    let document;

    beforeEach(() => {
        dom = new JSDOM(`
            <html>
                <body>
                    <input name="name" />
                    <input name="email" />
                    <input name="phone" />
                </body>
            </html>
        `);
        document = dom.window.document;
        global.chrome = {
            runtime: {
                sendMessage: jest.fn()
            }
        };
    });

    it('should inject an "Auto-Fill" button when form fields are detected', () => {
        const autoFillButton = document.querySelector('button');
        expect(autoFillButton).toBeNull();

        // Simulate DOM load
        window.dispatchEvent(new Event('load'));

        autoFillButton = document.querySelector('button');
        expect(autoFillButton).not.toBeNull();
        expect(autoFillButton.textContent).toBe('Auto-Fill');
        expect(autoFillButton.style.position).toBe('fixed');
        expect(autoFillButton.style.top).toBe('10px');
        expect(autoFillButton.style.right).toBe('10px');
        expect(autoFillButton.style.zIndex).toBe('9999');
        expect(autoFillButton.style.padding).toBe('10px 20px');
        expect(autoFillButton.style.backgroundColor).toBe('#007bff');
        expect(autoFillButton.style.color).toBe('white');
        expect(autoFillButton.style.border).toBe('none');
        expect(autoFillButton.style.borderRadius).toBe('4px');
        expect(autoFillButton.style.cursor).toBe('pointer');
    });

    it('should fill form fields with selected profile data when "Auto-Fill" button is clicked', () => {
        const autoFillButton = document.querySelector('button');

        // Simulate DOM load
        window.dispatchEvent(new Event('load'));

        chrome.runtime.sendMessage.mockResolvedValueOnce({
            profile: { name: 'John Doe', email: 'john@example.com', phone: '123-456-7890' }
        });

        autoFillButton.click();

        const nameField = document.querySelector('input[name="name"]');
        const emailField = document.querySelector('input[name="email"]');
        const phoneField = document.querySelector('input[name="phone"]');

        expect(nameField.value).toBe('John Doe');
        expect(emailField.value).toBe('john@example.com');
        expect(phoneField.value).toBe('123-456-7890');
    });

    it('should not fill form fields if no profile is selected', () => {
        const autoFillButton = document.querySelector('button');

        // Simulate DOM load
        window.dispatchEvent(new Event('load'));

        chrome.runtime.sendMessage.mockResolvedValueOnce({ profile: null });

        autoFillButton.click();

        const nameField = document.querySelector('input[name="name"]');
        const emailField = document.querySelector('input[name="email"]');
        const phoneField = document.querySelector('input[name="phone"]');

        expect(nameField.value).toBe('');
        expect(emailField.value).toBe('');
        expect(phoneField.value).toBe('');
    });
});