// profile_manager.test.js

import { jest } from '@jest/globals';

describe('Profile Manager', () => {
    let profiles;
    let selectedProfileIndex;

    beforeEach(() => {
        profiles = [];
        selectedProfileIndex = -1;
    });

    it('should add a new profile when the "Add Profile" button is clicked', async () => {
        const promptMock = jest.spyOn(window, 'prompt').mockReturnValueOnce('New Profile');
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#addProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(promptMock).toHaveBeenCalledWith('Enter profile name:');
        expect(profiles).toEqual([{ name: 'New Profile', email: '', phone: '' }]);
        expect(selectedProfileIndex).toBe(0);
    });

    it('should alert if no profile name is entered when adding a new profile', async () => {
        const promptMock = jest.spyOn(window, 'prompt').mockReturnValueOnce('');
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#addProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(promptMock).toHaveBeenCalledWith('Enter profile name:');
        expect(alertMock).toHaveBeenCalledWith('Please enter a valid profile name.');
    });

    it('should select a profile when a profile item is clicked', async () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        profiles.push({ name: 'Profile 2', email: '', phone: '' });

        const event = new Event('click');
        document.querySelector('#profileItem2').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(selectedProfileIndex).toBe(1);
    });

    it('should update the selected profile when a profile item is clicked', async () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        profiles.push({ name: 'Profile 2', email: '', phone: '' });

        const event = new Event('click');
        document.querySelector('#profileItem2').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(document.querySelector('#selectedProfileName').textContent).toBe('Profile 2');
    });

    it('should remove a profile when the "Remove Profile" button is clicked', async () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        selectedProfileIndex = 0;

        const confirmMock = jest.spyOn(window, 'confirm').mockReturnValueOnce(true);
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#removeProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(confirmMock).toHaveBeenCalledWith('Are you sure you want to remove this profile?');
        expect(profiles).toEqual([]);
        expect(selectedProfileIndex).toBe(-1);
    });

    it('should alert if no profile is selected when trying to remove a profile', async () => {
        const confirmMock = jest.spyOn(window, 'confirm').mockReturnValueOnce(true);
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#removeProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(confirmMock).not.toHaveBeenCalled();
        expect(alertMock).toHaveBeenCalledWith('Please select a profile to remove.');
    });

    it('should update the selected profile when editing a profile', async () => {
        profiles.push({ name: 'Profile 1', email: '', phone: '' });
        selectedProfileIndex = 0;

        const promptMock = jest.spyOn(window, 'prompt').mockReturnValueOnce('Updated Profile');
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#editProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(promptMock).toHaveBeenCalledWith('Enter new profile name:', 'Profile 1');
        expect(profiles).toEqual([{ name: 'Updated Profile', email: '', phone: '' }]);
        expect(document.querySelector('#selectedProfileName').textContent).toBe('Updated Profile');
    });

    it('should alert if no profile is selected when trying to edit a profile', async () => {
        const promptMock = jest.spyOn(window, 'prompt').mockReturnValueOnce('');
        const alertMock = jest.spyOn(window, 'alert').mockImplementation();

        const event = new Event('click');
        document.querySelector('#editProfileButton').dispatchEvent(event);

        await new Promise(resolve => setTimeout(resolve, 0));

        expect(promptMock).not.toHaveBeenCalled();
        expect(alertMock).toHaveBeenCalledWith('Please select a profile to edit.');
    });
});