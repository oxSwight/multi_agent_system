# Architecture Design — Database Schema & REST Contracts

```json
{
  "has_external_integrations" : false,
  "architecture_style" : "CLIENT_SERVER",
  "tech_stack" : {
    "language" : "Java",
    "framework" : "Spring Boot",
    "platform_apis" : [ "Manifest V3", "chrome.storage", "fetch" ],
    "build_tool" : "Maven"
  },
  "components" : [ {
    "name" : "UI",
    "type" : "UI",
    "responsibility" : "Display the clean, modern UI with professional CSS styling."
  }, {
    "name" : "FileUploader",
    "type" : "BACKGROUND_WORKER",
    "responsibility" : "Handle file uploads and communicate with the backend."
  }, {
    "name" : "ProfileManager",
    "type" : "BACKGROUND_WORKER",
    "responsibility" : "Manage multiple user profiles."
  }, {
    "name" : "ContentScript",
    "type" : "CONTENT_SCRIPT",
    "responsibility" : "Detect form fields on job boards and inject an 'Auto-Fill' button."
  }, {
    "name" : "ApplicationController",
    "type" : "CONTROLLER",
    "responsibility" : "Handle REST API endpoints for uploading files and fetching selected profile data."
  }, {
    "name" : "ProfileService",
    "type" : "SERVICE",
    "responsibility" : "Business logic for managing user profiles."
  }, {
    "name" : "ProfileRepository",
    "type" : "REPOSITORY",
    "responsibility" : "Database access layer for user profiles."
  }, {
    "name" : "ApplicationHistoryRepository",
    "type" : "REPOSITORY",
    "responsibility" : "Database access layer for application history."
  } ],
  "file_layout" : [ "frontend/manifest.json", "frontend/src/popup.html", "frontend/src/popup.css", "frontend/src/content_script.js", "frontend/src/background.js", "frontend/src/file_uploader.js", "frontend/src/profile_manager.js", "backend/pom.xml", "backend/docker-compose.yml", "backend/src/main/java/com/example/jobapp/Application.java", "backend/src/main/java/com/example/jobapp/controller/ApplicationController.java", "backend/src/main/java/com/example/jobapp/service/ProfileService.java", "backend/src/main/java/com/example/jobapp/repository/ProfileRepository.java", "backend/src/main/java/com/example/jobapp/repository/ApplicationHistoryRepository.java", "backend/src/test/java/com/example/jobapp/controller/ApplicationControllerTest.java", "backend/src/test/java/com/example/jobapp/service/ProfileServiceTest.java" ],
  "data_persistence" : {
    "type" : "RELATIONAL",
    "schema" : [ {
      "table_name" : "profiles",
      "columns" : [ {
        "name" : "id",
        "type" : "SERIAL",
        "is_primary" : true,
        "is_nullable" : false
      }, {
        "name" : "name",
        "type" : "VARCHAR(255)",
        "is_primary" : false,
        "is_nullable" : false
      } ]
    }, {
      "table_name" : "application_history",
      "columns" : [ {
        "name" : "id",
        "type" : "SERIAL",
        "is_primary" : true,
        "is_nullable" : false
      }, {
        "name" : "profile_id",
        "type" : "INTEGER",
        "is_primary" : false,
        "is_nullable" : false
      }, {
        "name" : "job_board",
        "type" : "VARCHAR(255)",
        "is_primary" : false,
        "is_nullable" : false
      }, {
        "name" : "application_date",
        "type" : "TIMESTAMP",
        "is_primary" : false,
        "is_nullable" : false
      } ]
    } ]
  },
  "api_contracts" : [ {
    "method" : "POST",
    "path" : "/api/profiles",
    "request_payload" : {
      "name" : "String"
    },
    "expected_response" : {
      "id" : "Integer"
    }
  }, {
    "method" : "GET",
    "path" : "/api/profiles/{id}",
    "request_payload" : { },
    "expected_response" : {
      "id" : "Integer",
      "name" : "String"
    }
  }, {
    "method" : "POST",
    "path" : "/api/files",
    "request_payload" : {
      "file" : "MultipartFile"
    },
    "expected_response" : {
      "message" : "String"
    }
  } ]
}
```
