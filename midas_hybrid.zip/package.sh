#!/bin/bash
set -euo pipefail
zip -r extension.zip manifest.json src/
echo "Packaged extension.zip"
