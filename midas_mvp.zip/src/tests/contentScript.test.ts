// tests/contentScript.test.ts

import { mockMatchResume } from '../src/contentScript';

describe('mockMatchResume', () => {
  it('should return true for a matching resume profile', () => {
    const resume = 'Software Engineer with experience in TypeScript and React.';
    expect(mockMatchResume(resume)).toBe(true);
  });

  it('should return false for a non-matching resume profile', () => {
    const resume = 'Data Scientist with experience in Python and R.';
    expect(mockMatchResume(resume)).toBe(false);
  });

  it('should be case-insensitive', () => {
    const resume = 'software engineer';
    expect(mockMatchResume(resume)).toBe(true);
  });

  it('should handle empty input', () => {
    const resume = '';
    expect(mockMatchResume(resume)).toBe(false);
  });
});