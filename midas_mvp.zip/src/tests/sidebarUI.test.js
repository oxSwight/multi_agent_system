// tests/sidebarUI.test.js

describe('Sidebar UI', () => {
  let matchResumeButton;
  let resumeInput;
  let resultDiv;

  beforeEach(() => {
    document.body.innerHTML = `
      <h1>Resume Matcher</h1>
      <input type="text" id="resumeInput" placeholder="Enter your resume keywords">
      <button onclick="matchResume()">Match Resume</button>
      <div id="result"></div>
    `;

    matchResumeButton = document.getElementById('matchResume');
    resumeInput = document.getElementById('resumeInput');
    resultDiv = document.getElementById('result');

    // Mock chrome.runtime.sendMessage
    global.chrome = {
      runtime: {
        sendMessage: jest.fn((message, callback) => {
          if (message.action === "matchResume") {
            const mockResponse = { matched: true };
            callback(mockResponse);
          }
        })
      }
    };

    require('../src/sidebarUI');
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should display a match result when the button is clicked', () => {
    resumeInput.value = 'Software Engineer with experience in TypeScript and React.';
    matchResumeButton.click();

    expect(resultDiv.textContent).toBe('Match found!');
  });

  it('should display no match result for non-matching input', () => {
    global.chrome.runtime.sendMessage.mockImplementationOnce((message, callback) => {
      if (message.action === "matchResume") {
        const mockResponse = { matched: false };
        callback(mockResponse);
      }
    });

    resumeInput.value = 'Data Scientist with experience in Python and R.';
    matchResumeButton.click();

    expect(resultDiv.textContent).toBe('No match found.');
  });

  it('should display an error message if chrome.runtime.sendMessage fails', () => {
    global.chrome.runtime.sendMessage.mockImplementationOnce((message, callback) => {
      throw new Error('Runtime error');
    });

    resumeInput.value = 'Software Engineer';
    matchResumeButton.click();

    expect(resultDiv.textContent).toBe('An error occurred while matching the resume.');
  });

  it('should display a message if the input is empty', () => {
    resumeInput.value = '';
    matchResumeButton.click();

    expect(resultDiv.textContent).toBe('Please enter your resume keywords.');
  });
});