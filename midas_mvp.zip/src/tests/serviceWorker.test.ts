// tests/serviceWorker.test.ts

import { chrome } from 'jest-chrome';

describe('Service Worker', () => {
  beforeEach(() => {
    jest.resetModules();
    require('../src/serviceWorker');
  });

  it('should handle mockMatch action with a matching resume', async () => {
    const mockFetch = jest.fn().mockResolvedValue({
      json: jest.fn().mockResolvedValue({ matched: true })
    });
    global.fetch = mockFetch;

    chrome.runtime.sendMessage({ action: "mockMatch", resume: "Software Engineer" }, (response) => {
      expect(response.matched).toBe(true);
    });

    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mockFetch).toHaveBeenCalledWith('https://example.com/match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resume: "Software Engineer" })
    });
  });

  it('should handle mockMatch action with a non-matching resume', async () => {
    const mockFetch = jest.fn().mockResolvedValue({
      json: jest.fn().mockResolvedValue({ matched: false })
    });
    global.fetch = mockFetch;

    chrome.runtime.sendMessage({ action: "mockMatch", resume: "Data Scientist" }, (response) => {
      expect(response.matched).toBe(false);
    });

    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mockFetch).toHaveBeenCalledWith('https://example.com/match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resume: "Data Scientist" })
    });
  });

  it('should handle errors during fetch', async () => {
    const mockFetch = jest.fn().mockRejectedValue(new Error('Network error'));
    global.fetch = mockFetch;

    chrome.runtime.sendMessage({ action: "mockMatch", resume: "Software Engineer" }, (response) => {
      expect(response.matched).toBe(false);
    });

    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mockFetch).toHaveBeenCalledWith('https://example.com/match', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resume: "Software Engineer" })
    });
  });
});