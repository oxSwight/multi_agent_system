// src/sidebarUI.js

document.addEventListener('DOMContentLoaded', () => {
  const matchResumeButton = document.getElementById('matchResume');
  const resumeInput = document.getElementById('resumeInput');
  const resultDiv = document.getElementById('result');

  matchResumeButton.addEventListener('click', () => {
    const resumeText = resumeInput.value.trim();
    if (resumeText === '') {
      resultDiv.textContent = 'Please enter your resume keywords.';
      return;
    }

    chrome.runtime.sendMessage({ action: "matchResume", resume: resumeText }, (response) => {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError);
        resultDiv.textContent = 'An error occurred while matching the resume.';
        return;
      }

      resultDiv.textContent = response.matched ? 'Match found!' : 'No match found.';
    });
  });
});