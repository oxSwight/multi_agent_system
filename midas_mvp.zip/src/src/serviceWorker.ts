// src/serviceWorker.ts

chrome.runtime.onInstalled.addListener(() => {
  console.log("Service worker installed");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "mockMatch") {
    const resume = message.resume;
    
    // Mock POST /match request
    fetch('https://example.com/match', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ resume })
    })
    .then(response => response.json())
    .then(data => {
      sendResponse({ matched: data.matched });
    })
    .catch(error => {
      console.error('Error:', error);
      sendResponse({ matched: false });
    });

    return true; // Keep the message channel open for sendResponse
  }
});