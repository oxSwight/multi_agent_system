// src/contentScript.ts

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "matchResume") {
    const resume = message.resume;
    // Mock matching logic
    const matchResult = mockMatchResume(resume);
    sendResponse({ matched: matchResult });
  }
});

function mockMatchResume(resume: string): boolean {
  // Hardcoded resume profile for matching
  const hardcodedProfile = "Software Engineer with experience in TypeScript and React.";
  
  // Simple keyword matching logic
  return hardcodedProfile.toLowerCase().includes(resume.toLowerCase());
}