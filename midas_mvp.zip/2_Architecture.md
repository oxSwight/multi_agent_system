# Architecture Design — Database Schema & REST Contracts

```json
{
  "has_external_integrations" : false,
  "architecture_style" : "CLIENT_ONLY",
  "tech_stack" : {
    "language" : "TypeScript",
    "framework" : "none",
    "platform_apis" : [ "Manifest V3", "chrome.storage", "fetch" ],
    "build_tool" : "none"
  },
  "components" : [ {
    "name" : "Content Script",
    "type" : "CONTENT_SCRIPT",
    "responsibility" : "Interacts with the web page."
  }, {
    "name" : "Service Worker",
    "type" : "SERVICE_WORKER",
    "responsibility" : "Handles background tasks and mock POST /match requests."
  }, {
    "name" : "Sidebar UI",
    "type" : "UI",
    "responsibility" : "Provides user interaction for matching a hardcoded resume profile."
  } ],
  "file_layout" : [ "src/contentScript.ts", "src/serviceWorker.ts", "src/sidebarUI.html", "src/sidebarUI.js", "tests/contentScript.test.ts", "tests/serviceWorker.test.ts", "tests/sidebarUI.test.js" ],
  "data_persistence" : {
    "type" : "BROWSER_STORAGE",
    "schema" : [ ]
  },
  "api_contracts" : [ ]
}
```
